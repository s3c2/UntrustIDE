/// <disable>JS2085</disable>
'use strict';
var DocContent = (function () {
    function DocContent(parameters) {
        this.Position = parameters.Position;
        this.Content = parameters.Content;
    }
    return DocContent;
}());
exports.DocContent = DocContent;
//# sourceMappingURL=doccontents.js.map