/// <disable>JS2085</disable>
'use strict';
/* --------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */
/**
 * util
 */
var util = (function () {
    function util(parameters) {
    }
    util.ConvertUriToPath = function (documentUri) {
        if (process.platform == 'win32') {
            if (documentUri.indexOf('file:///', 0) == 0) {
                // remove the starting 'file:///' of file uri
                var documentPath = documentUri.substring('file:///'.length);
                documentPath = documentPath.replace(/\//g, '\\').replace(/%3A/, ':');
                return documentPath;
            }
            else {
                return documentUri;
            }
        }
        else {
            if (process.platform == 'linux' || process.platform == 'darwin') {
                if (documentUri.indexOf('file:///', 0) == 0) {
                    // remove the starting 'file:///' of file uri
                    var documentPath = documentUri.substring('file://'.length);
                    return documentPath;
                }
                else {
                    return documentUri;
                }
            }
        }
    };
    return util;
}());
exports.util = util;
//# sourceMappingURL=util.js.map